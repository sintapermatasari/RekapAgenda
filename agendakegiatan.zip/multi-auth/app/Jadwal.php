<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jadwal extends Model
{
  protected $fillable = [
        'nis', 'tanggal', 'waktu_awal', 'waktu_akhir', 'kegiatan', 'mapel'
    ];
}
