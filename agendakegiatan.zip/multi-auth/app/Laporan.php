<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Laporan extends Model
{
    protected $fillable = [
        'nis', 'tanggal', 'waktu_awal', 'waktu_akhir', 'kegiatan', 'bukti'
    ];
}
