@extends('laporans.layout')
 
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Bukti Aktivitas</h2>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>NIS</th>
            <th>Tanggal</th>
            <th>Waktu Awal</th>
            <th>Waktu Akhir</th>
            <th>Kegiatan</th>
            <th>Bukti</th>
        </tr>
        @foreach ($laporans as $laporan)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $laporan->nis }}</td>
            <td>{{ $laporan->tanggal }}</td>
            <td>{{ $laporan->waktu_awal }}</td>
            <td>{{ $laporan->waktu_akhir }}</td>
            <td>{{ $laporan->kegiatan }}</td>
            <td>{{ $laporan->bukti }}</td>  
        </tr>
        @endforeach
    </table>
  
    {!! $laporans->links() !!}
      
@endsection