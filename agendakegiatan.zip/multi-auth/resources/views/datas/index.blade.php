@extends('datas.layout')
 
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Data Diri Siswa</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('datas.create') }}">Menambah Data Baru</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nama Siswa</th>
            <th>Tanggal Lahir</th>
            <th>Jenis Kelamin</th>
            <th>Nama Ayah</th>
            <th>Nama Ibu</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($datas as $data)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $data->nama }}</td>
            <td>{{ $data->ttl }}</td>
            <td>{{ $data->jk }}</td>
            <td>{{ $data->ayah }}</td>
            <td>{{ $data->ibu }}</td>
            <td>
                <form action="{{ route('datas.destroy',$data->id) }}" method="POST">
    
                    <a class="btn btn-primary" href="{{ route('datas.edit',$data->id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
  
    {!! $datas->links() !!}
      
@endsection