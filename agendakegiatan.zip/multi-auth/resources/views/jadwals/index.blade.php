@extends('jadwals.layout')
 
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Set Jadwal</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('jadwals.create') }}">Membuat Jadwal Baru</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>NIS</th>
            <th>Tanggal</th>
            <th>Waktu Awal</th>
            <th>Waktu Akhir</th>
            <th>Kegiatan</th>
            <th>Mata Pelajaran</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($jadwals as $jadwal)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $jadwal->nis }}</td>
            <td>{{ $jadwal->tanggal }}</td>
            <td>{{ $jadwal->waktu_awal }}</td>
            <td>{{ $jadwal->waktu_akhir }}</td>
            <td>{{ $jadwal->kegiatan }}</td>
            <td>{{ $jadwal->mapel }}</td>
            <td>
                <form action="{{ route('jadwals.destroy',$jadwal->id) }}" method="POST">
    
                    <a class="btn btn-primary" href="{{ route('jadwals.edit',$jadwal->id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
  
    {!! $jadwals->links() !!}
      
@endsection