@extends('jadwals.layout')
   
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Jadwal </h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('jadwals.index') }}"> Back</a>
            </div>
        </div>
    </div>
   
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
  
    <form action="{{ route('jadwals.update',$jadwal->id) }}" method="POST">
        @csrf
        @method('PUT')
   
         <div class="row">
         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>NIS:</strong>
                <input type="integer" name="nis" value="{{ $jadwal->nis }}" class="form-control" placeholder="NIS">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Tanggal:</strong>
                <input type="date" name="tanggal" value="{{ $jadwal->tanggal }}" class="form-control" placeholder="Tanggal">
            </div>
        </div>
         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Waktu Awal:</strong>
                <input type="time" name="waktu_awal" value="{{ $jadwal->waktu_awal }}" class="form-control" placeholder="Waktu Awal">
            </div>
        </div>
         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Waktu Akhir:</strong>
                <input type="time" name="waktu_akhir" value="{{ $jadwal->waktu_akhir }}" class="form-control" placeholder="Waktu Akhir">
            </div>
        </div>
         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Kegiatan:</strong>
                <input type="string" name="kegiatan" value="{{ $jadwal->kegiatan }}" class="form-control" placeholder="Kegiatan">
            </div>
        </div>
         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Mata Pelajaran:</strong>
                <input type="string" name="mapel" value="{{ $jadwal->mapel }}" class="form-control" placeholder="Mata Pelajaran">
            </div>
        </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
   
    </form>
@endsection