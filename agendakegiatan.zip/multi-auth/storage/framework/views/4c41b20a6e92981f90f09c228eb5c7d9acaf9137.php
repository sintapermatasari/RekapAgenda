
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Bukti Aktivitas</h2>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>NIS</th>
            <th>Tanggal</th>
            <th>Waktu Awal</th>
            <th>Waktu Akhir</th>
            <th>Kegiatan</th>
            <th>Bukti</th>
        </tr>
        <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($laporan->nis); ?></td>
            <td><?php echo e($laporan->tanggal); ?></td>
            <td><?php echo e($laporan->waktu_awal); ?></td>
            <td><?php echo e($laporan->waktu_akhir); ?></td>
            <td><?php echo e($laporan->kegiatan); ?></td>
            <td><?php echo e($laporan->bukti); ?></td>  
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $laporans->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('laporans.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multi-auth\resources\views/laporans/index.blade.php ENDPATH**/ ?>